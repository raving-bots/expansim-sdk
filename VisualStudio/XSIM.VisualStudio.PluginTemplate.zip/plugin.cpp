#include "pch.hpp"

#include <xsim/xsim.hpp>

// include interfaces you're interested in from <xsim/generated/IPluginXxx.hpp> e.g.
#include <xsim/generated/IPluginNotifySpawnV1.hpp>

// stable interfaces have version in the name: they will not change over time
//
// unstable interfaces are in xsim::unstable namespace and may change between simulator builds
// (when that happens your plugin will no longer load), but they expose the latest functionality
// before it gets frozen into versioned interfaces

namespace plugin
{
	// the name of the class or the namespace doesn't matter and is up to you
	// it must inherit from xsim::PluginV1<> however, and specify at least one interface
	struct $projectname$ final
		: xsim::PluginV1<xsim::IPluginNotifySpawnV1>
	{
		void OnVehicleSpawned(xsim::Ptr<const xsim::VehicleSetupInfoV1> vehicle) noexcept override
		{
			xsim::Protect([&]
			{
				// interface methods must not raise exceptions
			});
		}

		void OnVehicleDespawned() noexcept override
		{
			xsim::Protect([&]
			{
				// interface methods must not raise exceptions
			});
		}
	};
}

// this function is required
std::unique_ptr<xsim::IPluginWrapper> xsim::GetPlugin()
{
	// you must call MakePlugin to create the wrapper
	return xsim::MakePlugin<plugin::$projectname$>();
}
