#include "pch.hpp"

#include <xsim/xsim.hpp>

namespace xsim
{
	XSIM_EXPORT void CalculateCatTrackHub(
		Entity entity,
		int32_t index,
		DeltaTime dt,
		Ptr<const CatTrackConfig> config,
		Ptr<const CatTrackState> state,
		Ptr<const InOutConfig> inputConfig,
		Ptr<const VehicleControllerData> controller,
		Ptr<const VehicleConfig> vehicleConfig,
		Ptr<const VehicleState> vehicleState,
		Ptr<const MotorEngineConfig> engineConfig,
		Ptr<const MotorEngineState> engineState,
		Ptr<InOutState> inputState
	) noexcept
	{
		Protect([&]
		{
		});
	}

	XSIM_EXPORT void CalculateMotorEngine(
		Entity entity,
		int32_t index,
		DeltaTime dt,
		Ptr<const MotorEngineConfig> config,
		Ptr<const InOutConfig> outputConfig,
		Ptr<const VehicleControllerData> controller,
		Ptr<MotorEngineState> state,
		Ptr<InOutState> outputState
	) noexcept
	{
		Protect([&]
		{
		});
	}

	XSIM_EXPORT void CalculateVehicleController(
		Ptr<VehicleControllerData> controller,
		Ptr<ForceFeedback> forceFeedback
	) noexcept
	{
		Protect([&]
		{
		});
	}

	XSIM_EXPORT void CalculateWheelHub(
		Entity entity,
		int32_t index,
		DeltaTime dt,
		Ptr<const WheelConfig> config,
		Ptr<const WheelState> state,
		Ptr<const InOutConfig> inputConfig,
		Ptr<const VehicleControllerData> controller,
		Ptr<const VehicleConfig> vehicleConfig,
		Ptr<const VehicleState> vehicleState,
		Ptr<const MotorEngineConfig> engineConfig,
		Ptr<const MotorEngineState> engineState,
		Ptr<InOutState> inputState
	) noexcept
	{
		Protect([&]
		{
		});
	}

	XSIM_EXPORT void OnPluginLoad(
		LogSinkFn logSink
	) noexcept
	{
		Protect([&]
		{
			SetLogSink(logSink);
		});
	}

	XSIM_EXPORT void OnPluginUnload() noexcept
	{
		Protect([&]
		{
			SetLogSink(nullptr);
		});
	}

	XSIM_EXPORT void OnVehicleDespawned() noexcept
	{
		Protect([&]
		{
		});
	}

	XSIM_EXPORT void OnVehicleSpawned(
		Ptr<const VehicleSetupInfo> vehicleSetup
	) noexcept
	{
		Protect([&]
		{
		});
	}

	XSIM_EXPORT void OnVehicleTelemetry(
		DeltaTime dt,
		Ptr<const VehicleConfig> vehicleConfig,
		Ptr<const VehicleState> vehicleState,
		Ptr<const RigidbodyState> rigidbody,
		bool hasTransmission,
		Ptr<const ManifoldState> manifoldState,
		Ptr<const TransmissionConfig> transmissionConfig,
		bool hasEngine,
		Ptr<const MotorEngineState> engineState
	) noexcept
	{
		Protect([&]
		{
		});
	}
}
